# pedido-namoro-exemplo
Projetinho criado para fins de namoro, pena que o response status dela deu 401. Apesar de tudo, pude aprender mais sobre como servir sites estáticos com Amazon AWS S3, CloudFrond e a configuração do https com domínio próprio no Route 53.


[VER DEMO](https://quero-voce.netlify.app/)
